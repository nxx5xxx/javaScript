console.log('Hello JavaScript'); 
console.log(123);
console.log(true);

//한줄주석
/*
    여러줄 주석
*/

